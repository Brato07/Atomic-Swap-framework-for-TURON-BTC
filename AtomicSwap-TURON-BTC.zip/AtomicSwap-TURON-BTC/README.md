
# Atomic Swap Framework: TURON ↔ BTC

This is a production-ready framework for performing **atomic swaps** between TURON (ERC-20) and Bitcoin (BTC) using **HTLCs**.

## Structure
- contracts/        Solidity ERC-20 HTLC for TURON
- backend/          Python swap manager for orchestration
- scripts/          Deployment scripts for ERC-20 HTLC
- requirements.txt  Python dependencies

## Setup
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Configure `.env` or environment variables for:
   - Ethereum private key
   - BTC wallet credentials
   - Infura/Alchemy node URL
3. Compile and deploy `TuronHTLC.sol` using `deploy_htlc.py`
4. Use `swap_manager.py` to orchestrate BTC and TURON HTLCs.

## Security
- Use testnets before mainnet deployment.
- Never hardcode private keys; use secure vaults or environment variables.
- Timelocks should be set carefully to prevent asset loss.
