
from web3 import Web3
import json

ETH_NODE = "https://mainnet.infura.io/v3/YOUR_INFURA_PROJECT_ID"
web3 = Web3(Web3.HTTPProvider(ETH_NODE))

# Load compiled contract ABI & bytecode (from TuronHTLC.sol compilation)
with open('../contracts/TuronHTLC.json') as f:
    contract_data = json.load(f)

abi = contract_data['abi']
bytecode = contract_data['bytecode']

# Deploy contract example
account = web3.eth.account.from_key('YOUR_PRIVATE_KEY')
contract = web3.eth.contract(abi=abi, bytecode=bytecode)
tx_hash = contract.constructor('TOKEN_ADDRESS', 'RECEIVER_ADDRESS', 'HASHLOCK', 3600).transact({'from': account.address})
tx_receipt = web3.eth.wait_for_transaction_receipt(tx_hash)
print("HTLC deployed at:", tx_receipt.contractAddress)
